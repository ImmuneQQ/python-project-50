# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pytest>=7.2.0,<8.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main',
                     'test1 = gendiff.scripts.test1:main']}

setup_kwargs = {
    'name': 'gendiff',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ImmuneQQ/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/82aeba8ea13c574d49bc/maintainability)](https://codeclimate.com/github/ImmuneQQ/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/82aeba8ea13c574d49bc/test_coverage)](https://codeclimate.com/github/ImmuneQQ/python-project-50/test_coverage)\n[![Pylint](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pylint.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pylint.yml)\n[![Python package](https://github.com/ImmuneQQ/python-project-50/actions/workflows/python-package.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/python-package.yml)\n[![Python CI](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pyci.yml)\n\n\n[![asciicast](https://asciinema.org/a/cY7sS222VIiz20NJWg1w83J9c.svg)](https://asciinema.org/a/cY7sS222VIiz20NJWg1w83J9c)',
    'author': 'immuneQQ',
    'author_email': 'vitalyasatka@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
