from gendiff import file_parser
import itertools


def generate_diff(file_path1, file_path2):
    file1 = file_parser.get_parsed_data(file_path1)
    file2 = file_parser.get_parsed_data(file_path2)
    return generate_string(file1, file2)


def generate_string(value1, value2):
    if value1 == {} and value2 == {}:
        return ''
    def walk(current_value1, depth, current_value2):
        all_keys = {}
        for key in current_value1.keys():
            all_keys[key] = 1
        for key in current_value2.keys():
            all_keys[key] = all_keys.get(key, 0) + 2
        all_unique_keys = sorted(all_keys)

        lines = []
        for key in all_unique_keys:
            if all_keys[key] == 1:
                val = current_value1[key]
                if isinstance(val, dict):
                    val = walk(val, depth + 1, val)
                else:
                    val = val_check_spec(val)
                lines.append(f"{depth * '    '}  - {key}: {val}")
            if all_keys[key] == 2:
                val = current_value2[key]
                if isinstance(val, dict):
                    val = walk(val, depth + 1, val)
                else:
                    val = val_check_spec(val)
                lines.append(f"{depth * '    '}  + {key}: {val}")
            if all_keys[key] == 3:
                val1 = current_value1[key]
                val1 = val_check_spec(val1)
                val2 = current_value2[key]
                val2 = val_check_spec(val2)
                if not isinstance(val1, dict) or not isinstance(val2, dict):
                    if (isinstance(val1, dict)):
                        val1 = walk(val1, depth + 1, val1)
                    if (isinstance(val2, dict)):
                        val2 = walk(val2, depth + 1, val2)
                    if val1 == val2:
                        lines.append(f"{(depth + 1) * '    '}{key}: {val1}")
                    else:
                        lines.append(f"{depth * '    ' + '  - '}{key}: {val1}")
                        lines.append(f"{depth * '    ' + '  + '}{key}: {val2}")
                else:
                    lines.append(
                        f"{(depth + 1) * '    '}{key}: {walk(val1, depth + 1, val2)}")
        result = itertools.chain('{', lines, [depth * '    ' + '}'])
        return '\n'.join(result)
    return walk(value1, 0, value2)


def val_check_spec(val):
    if (val == True):
        return 'true'
    if (val == False):
        return 'false'
    if (val == None):
        return 'null'
    return val
