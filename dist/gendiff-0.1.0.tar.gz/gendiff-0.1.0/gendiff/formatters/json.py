import json


def json_form(diff):
    return json.dumps(diff)
