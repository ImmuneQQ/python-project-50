### Hexlet tests and linter status:
[![Actions Status](https://github.com/ImmuneQQ/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/82aeba8ea13c574d49bc/maintainability)](https://codeclimate.com/github/ImmuneQQ/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/82aeba8ea13c574d49bc/test_coverage)](https://codeclimate.com/github/ImmuneQQ/python-project-50/test_coverage)
[![Pylint](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pylint.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pylint.yml)
[![Python package](https://github.com/ImmuneQQ/python-project-50/actions/workflows/python-package.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/python-package.yml)
[![Python CI](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/ImmuneQQ/python-project-50/actions/workflows/pyci.yml)


[![asciicast](https://asciinema.org/a/cY7sS222VIiz20NJWg1w83J9c.svg)](https://asciinema.org/a/cY7sS222VIiz20NJWg1w83J9c)