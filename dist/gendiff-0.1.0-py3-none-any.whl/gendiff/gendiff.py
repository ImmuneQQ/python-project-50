import json


def generate_diff(file_path1, file_path2):
    file1 = json.load(open(file_path1))
    file2 = json.load(open(file_path2))
    joint_dict = {}
    result = ''
    for key, value in file1.items():
        joint_dict[key] = joint_dict.get(key, [])
        joint_dict[key].append((1, value))
    for key, value in file2.items():
        joint_dict[key] = joint_dict.get(key, [])
        joint_dict[key].append((2, value))
    joint_dict = dict(sorted(joint_dict.items()))
    for key, value in joint_dict.items():
        if len(value) == 1:
            if value[0][0] == 1:
                result = f"{result}  - {key}: {value[0][1]}\n"
            else:
                result = f"{result}  + {key}: {value[0][1]}\n"
        if len(value) == 2:
            if value[0][1] == value[1][1]:
                result = f"{result}    {key}: {value[0][1]}\n"
            else:
                result = f"{result}  - {key}: {value[0][1]}\n"
                result = f"{result}  + {key}: {value[1][1]}\n"
    result = "{\n" + result + "}"
    return result